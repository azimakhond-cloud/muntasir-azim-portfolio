# Muntasir Azim — Portfolio Website

This is a static HTML/CSS/JavaScript portfolio website.

## Files
- `index.html` — page structure and original portfolio content
- `style.css` — original styling, responsive layout, animations and visual artwork styling
- `script.js` — mobile navigation, reveal animations, year and email contact form behavior
- `netlify.toml` — Netlify publish configuration

## Run locally
Open `index.html` in a modern browser. For a local development server, use VS Code Live Server.

## Publish with GitHub Pages
1. Create a new public repository on GitHub.
2. Upload all files in this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.

## Publish with Netlify
1. Sign in to Netlify.
2. Choose **Add new site → Deploy manually**.
3. Drag and drop this folder (or its ZIP contents) into the deploy area.
4. Netlify will provide a live `*.netlify.app` URL.

You can also connect the GitHub repository in Netlify so future GitHub pushes deploy automatically.

## Important
The contact form currently opens the visitor's default email app using the email address already present in the original HTML. It does not store submissions on a server.
